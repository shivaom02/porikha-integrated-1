import { createContext} from 'react';

const ClassContext = createContext();

export default ClassContext;