import { createContext } from 'react'

const StudentContext = createContext();
 
export default StudentContext
