import {createContext} from "react";

const webCamContext=createContext();

export default webCamContext;