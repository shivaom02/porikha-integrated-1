import React from 'react'

const Noresults = () => {
    return (
        <tr>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
        </tr>
    )
}

export default Noresults
