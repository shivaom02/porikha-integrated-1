import React from 'react';
import AuthContext from '../../context/authContexts/authContext';
import '../../App.css';

const confirmationPage = () => {
  return (
    <div>
      <h1>Confirm your email!</h1>
    </div>
  );
};

export default confirmationPage;
