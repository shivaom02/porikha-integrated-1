export const markButton={
    height:'40px',
    display:'flex',
    flexDirection:'column',
    justifyContent:'space-around',
    allignItems:'center',
    marginLeft:'5px'   
}

  export const buttonS = {
    height:'20px',
    width:'35px',
    padding:'2px 3px'
  }

  export const markListStyle = {
    backgroundColor:'#ddd',
    position:'relative',
    height:'60px',
    marginTop:'-70px',
    marginLeft:'55%',
    borderRadius:'10px',
    fontSize:'1em',
    display:'flex',
    flexDirection:'row',
    justifyContent:'spaceAround',
    padding:'5px'
  }

  export const buttonM={
    height:'20px',
    width:'35px',
    padding:'2px 3px'
  }

  export const markContainerDesciption = {
    color:'white',marginTop:'100px',
    height:'40px',
    display:'flex',
    flexDirection:'column',
    justifyContent:'space-around',
    allignItems:'center'
  }

  export const questionAnswer = {
    height:'1000px',
    width:'100vw',
    display:'flex',
    justifyContent:'space-around',
    allignItems:'center'
  }