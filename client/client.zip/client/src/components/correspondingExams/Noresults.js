import React from 'react'

const Noresults = () => {
    return (
            <tr style={{color:'black'}}>
               <td>NA</td>
               <td>NA</td>   
                <td>0</td>
           </tr>
    )
}

export default Noresults
