import React from 'react'

import '../../css/classhall.css';

const Noresults = () => {
    return (
        <div style={{color:'white',fontSize:'2rem'}}>
            Nothing to show
        </div>
    )
}
export default Noresults;