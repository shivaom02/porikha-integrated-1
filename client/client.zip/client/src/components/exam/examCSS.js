export const formContainer = {
    height:'120px',
    width:'250px',
    display:'flex',
    flexDirection:'column',
    justifyContent:'space-around',
    allignItems:'center'
}